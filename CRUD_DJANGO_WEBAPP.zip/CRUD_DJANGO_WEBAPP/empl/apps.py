from django.apps import AppConfig


class EmplConfig(AppConfig):
    name = 'empl'
