

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('empl', '0001_initial'),
    ]

    operations = [
        migrations.AddField(
            model_name='employee',
            name='pic',
            field=models.ImageField(default='e.png', upload_to='uploads'),
        ),
    ]
